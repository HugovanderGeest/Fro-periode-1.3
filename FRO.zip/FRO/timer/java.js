function diff_min(dt2, dt1) 
 {

  var diff =(dt2.getTime() - dt1.getTime()) / 1000;
  diff /= 60;
  return Math.abs(Math.round(diff));
  
 }

dt1 = new Date(2020,2,2);
dt2 = new Date(2020,6,2);
console.log(diff_min(dt1, dt2));

var verschil = document.getElementById('verschil');
verschil.innerHTML = diff_min(dt1, dt2);
// verschil.innerHTML = dt1 && dt2;
// var diff = document.getElementById('verschil');
// verschil.innerHTML = diff;

