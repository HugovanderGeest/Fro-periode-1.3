let objectArray = []; 

function imageObject(name, description) {
    let imgObj = this; 
    imgObj.name = name;
    imgObj.description = description;
    console.log(name);

}

function createObject() {
    for (counter = 0; counter < Link.length; counter++) {
        objectArray.push(new ImageObject(Link[counter], counter));
}
}

createObject();
    