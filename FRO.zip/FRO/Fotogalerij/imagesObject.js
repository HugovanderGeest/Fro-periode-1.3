function creatJASON() {
    let id = document.getElementById(Element: 'json');

    let applicationData = 

    let json = document.createElement('a');
    json.href = 'data:' + applicationData;
    json.download.


    id.appendChild(json);
}

function setStorage()

function getStorage()

function useStorage()

creatObject();
creatJASON();
showRandomImages();