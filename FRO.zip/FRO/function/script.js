let Mens = {
    voornaam: 'Hugo', 
    achternaam: 'Geest', 
    tussenvoegsel: 'van der'


};

function show() {
    console.log(Mens.voornaam, Mens.achternaam, Mens.tussenvoegsel);

}

show();